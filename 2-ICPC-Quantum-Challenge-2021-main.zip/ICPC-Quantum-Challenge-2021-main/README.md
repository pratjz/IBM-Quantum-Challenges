# ICPC-Quantum-Challenge-2021

In this repository you will find the original version of the exercises used in the [ICPC Quantum Computing Challenge Sponsored by IBM Quantum](https://challenges.quantum-computing.ibm.com/icpc).

Each exercise folder corresponds to a tab in the challenge page. The notebooks, within each folder, contain the problems presented for that respective challenge exercise.
